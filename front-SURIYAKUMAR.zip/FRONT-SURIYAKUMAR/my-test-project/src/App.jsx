import { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [posts, setPosts] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPost, setSelectedPost] = useState(null);
  
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isHeaderVisible, setIsHeaderVisible] = useState(true);

  useEffect(() => {
    fetch('https://cloud.codesupply.co/endpoint/react/data.json')
      .then(response => response.json())
      .then(data => setPosts(data))
      .catch(error => console.error("Error fetching data:", error));
  }, []);

  useEffect(() => {
    let lastScrollYValue = window.scrollY;

    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      if (currentScrollY === 0) {
        setIsHeaderVisible(true);
      } 
      else if (currentScrollY > 200 && currentScrollY > lastScrollYValue) {
        setIsHeaderVisible(false);
      } 
      else if (currentScrollY < lastScrollYValue) {
        setIsHeaderVisible(true);
      }

      lastScrollYValue = currentScrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []); 

  const filteredPosts = posts.filter((post) => {
    const lowerCaseQuery = searchQuery.toLowerCase();
    return (
      post.title.toLowerCase().includes(lowerCaseQuery) ||
      post.text.toLowerCase().includes(lowerCaseQuery)
    );
  });

  return (
    <div>
      <header className={`main-header ${isHeaderVisible ? 'visible' : 'hidden'}`}>
        <h1>My Logo</h1>
        
        <nav className="desktop-nav">
          <ul>
            <li>Home</li>
            <li className="dropdown-parent">
              Services ▼
              <ul className="dropdown-menu">
                <li>Web Design</li>
                <li>Development</li>
              </ul>
            </li>
          </ul>
        </nav>

        <button className="hamburger-btn" onClick={() => setIsMobileMenuOpen(true)}>
          ☰
        </button>
      </header>

      {isMobileMenuOpen && (
        <div className="mobile-menu-overlay" onClick={() => setIsMobileMenuOpen(false)}> 
          <div className="mobile-menu-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-mobile-btn" onClick={() => setIsMobileMenuOpen(false)}> 
              ✕ Close
            </button>
            <ul className="mobile-nav-links">
              <li>Home</li>
              <li>Services</li>
              <li>Web Design</li>
              <li>Development</li>
            </ul>
          </div>
        </div>
      )}
      
      <main className="posts-container">
        <div className="search-container">
          <input 
            type="text" 
            placeholder="Search posts..." 
            className="search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)} 
          />
        </div>

        <div className="posts-grid">
          {filteredPosts.map((post, index) => (
            <div className="post-card" key={index} onClick={() => setSelectedPost(post)}>
              <img 
                src={post.img} 
                srcSet={`${post.img} 1x, ${post.img_2x} 2x`} 
                alt={post.title} 
                className="post-image"
              />
              <div className="post-content">
                <span className="post-meta">{post.autor} • {post.date}</span>
                <h3 className="post-title">{post.title}</h3>
                <p className="post-description">{post.text}</p>
              </div>
            </div>
          ))}
        </div>
      </main>

      {selectedPost && (
        <div className="modal-overlay" onClick={() => setSelectedPost(null)}> 
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>{selectedPost.title}</h2>
            <p>{selectedPost.text}</p>
            <button className="close-button" onClick={() => setSelectedPost(null)}> 
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default App;